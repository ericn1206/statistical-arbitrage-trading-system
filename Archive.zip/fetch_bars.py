import os
import requests
from dotenv import load_dotenv

# Load values from .env into Python
load_dotenv()

# Get Alpaca credentials and base URL
API_KEY = os.getenv("ALPACA_API_KEY")
SECRET_KEY = os.getenv("ALPACA_SECRET_KEY")
DATA_URL = os.getenv("ALPACA_DATA_URL")

# Headers are how we prove to Alpaca who we are
HEADERS = {
    "APCA-API-KEY-ID": API_KEY,
    "APCA-API-SECRET-KEY": SECRET_KEY,
}


def fetch_bars(symbol, start, end, timeframe):
    """
    Ask Alpaca for historical price bars for ONE stock.
    """

    # This is the Alpaca endpoint for historical bars
    url = f"{DATA_URL}/v2/stocks/bars"

    # These are the filters we send to Alpaca
    params = {
        "symbols": symbol,
        "start": start,
        "end": end,
        "timeframe": timeframe,
        "feed": "iex",          
    }

    # Make the HTTP request
    response = requests.get(url, headers=HEADERS, params=params)

    # If Alpaca says something went wrong, crash loudly
    response.raise_for_status()

    # Convert response to Python dictionary
    data = response.json()

    # Return just the bars for this symbol
    return data["bars"][symbol]

# More of a test
if __name__ == "__main__":
    bars = fetch_bars(
        symbol="AAPL",
        start="2024-01-01",
        end="2024-01-10",
        timeframe="1Day",
    )

    for bar in bars:
        print(bar)
