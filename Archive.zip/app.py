print("statarb setup OK")
